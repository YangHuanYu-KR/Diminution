import pandas as pd
import matplotlib.pyplot as plt
from pathlib import Path
import ast
import sys
import re
from matplotlib.ticker import ScalarFormatter
from matplotlib.ticker import FixedLocator

def parse_list_cell(cell):
    if pd.isna(cell):
        return []
    if isinstance(cell, (list, tuple)):
        return list(cell)
    if isinstance(cell, (int, float)):
        return [float(cell)]
    s = str(cell).strip()
    try:
        val = ast.literal_eval(s)
        if isinstance(val, (list, tuple)):
            return list(val)
        if isinstance(val, (int, float)):
            return [float(val)]
    except Exception:
        pass
    sep = ';' if ';' in s and ',' not in s else ','
    parts = [p.strip() for p in s.strip('[]').split(sep)]
    lst = []
    for p in parts:
        cleaned = re.sub(r'[^\d\.\-]+$', '', p)
        try:
            lst.append(float(cleaned))
        except ValueError:
            lst.append(None)
    return lst

def collect_step_values(lists, max_steps=30):
    """Collect non-timeout, existing values per step up to max_steps."""
    data = []
    for i in range(max_steps):
        vals = [lst[i] for lst in lists if i < len(lst) and lst[i] is not None and lst[i] != -1]
        data.append(vals)
    return data

def plot_metric_boxplots(root_dir: str):
    root = Path(root_dir)
    files = [
        ("processed_clingo_related.csv", "Clingo Related"),
        ("processed_clingo_unrelated.csv", "Clingo Unrelated"),
        ("processed_DLV2_related.csv", "DLV2 Related"),
        ("processed_DLV2_unrelated.csv", "DLV2 Unrelated")
    ]
    metrics = [
        ("t_solve_list", "Solving time (s)"),
        ("t_ground_list", "Grounding time (s)"),
        ("ground_file_bytes_list", "Ground file size (B)"),
        ("rules_list", "Number of rules")
    ]
    max_steps = 30
    
    for metric, ylabel in metrics:
        fig, axes = plt.subplots(2, 2, figsize=(14, 10), sharex=True, sharey=False)
        axes = axes.flatten()
        for ax, (fname, label) in zip(axes, files):
            path = root / fname
            if not path.exists():
                ax.set_visible(False)
                continue
            df = pd.read_csv(path)
            if metric not in df.columns:
                ax.set_visible(False)
                continue
            lists = df[metric].apply(parse_list_cell).tolist()

            
            data = collect_step_values(lists, max_steps)
            # Boxplot positions at 0..max_steps-1
            positions = list(range(max_steps))
            ax.boxplot(data, positions=positions, showfliers=False)
            ax.set_title(label)
            ax.set_xlabel("Step")
            ax.set_ylabel(ylabel)
            
            ax.xaxis.set_major_locator(FixedLocator(range(0, max_steps+1, 5)))
            ax.set_xlim(-0.5, max_steps + 0.5)
            ax.tick_params(axis='x', labelrotation=0)
            
            fmt = ScalarFormatter()
            fmt.set_useOffset(False)
            fmt.set_scientific(False)
            ax.xaxis.set_major_formatter(fmt)
            ax.tick_params(axis='x', labelrotation=0)
        plt.suptitle(f"Boxplot of {ylabel} by Step (0–{max_steps-1})")
        plt.tight_layout(rect=[0, 0.03, 1, 0.95])
        out_pdf = root / f"{metric}_boxplot.pdf"
        plt.savefig(out_pdf)
        # plt.show()
        print(f"Saved: {out_pdf.resolve()}")

if __name__ == "__main__":
    dir_arg = sys.argv[1] if len(sys.argv) > 1 else "vh"
    plot_metric_boxplots(dir_arg)
